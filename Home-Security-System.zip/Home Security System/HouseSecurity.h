#pragma once
#include "SecurityStatus.h"
#include "SensorInfo.h"

class HouseSecurity :public SecurityStatus ///(Concrete Subject)  
{
	///ConcreteSubject : The HouseSecurity Class [5 marks] 
	//Public Class HouseSecurity 
	//Inherits SecurityStatus 

	///State: The Status of the sensors 
	//Private mySensorStatus As SensorInfo 
	SensorInfo mySensorStatus;

public:

	//This function will be called by observers to get current Status of the sensors [4 marks]
	//Public Function GetSensorStatus () As SensorInfo   
	//Return mySensorStatus 
	//End Function 	
	SensorInfo GetSensorStatus();

	///Some external client will call this to set the sensor's position[4 marks] 
	//Public Function SetSensorStatus(ByVal defaultStatus As SensorInfo) 
	//mySensorStatus = defaultStatus

	///Once the sensor status is updated, we have to notify observers  
	//NotifyObservers() 
	//End Function 
	void SetSensorStatus(SensorInfo info);

	//Remarks: This can also be implemented as a get/set property 
	//End Class 
	///END CLASS DEFINITION HouseSecurity
};
