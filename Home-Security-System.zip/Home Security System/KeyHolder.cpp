#include "KeyHolder.h"
#include <string>

KeyHolder::KeyHolder(HouseSecurity *hs, string name, string phone, string email)
{
	h = hs;
	myName = name;
	myPhoneNumber = phone;
	myEmail = email;
}

void KeyHolder::Update()
{
	currentSensorState = h->GetSensorStatus();
	cout << "KeyHolder " << myName << " says that the status of windows 1, 2 and 3 is " << boolalpha << currentSensorState.window1 << ", " << boolalpha << currentSensorState.window2 << ", " << boolalpha << currentSensorState.door << endl;
}