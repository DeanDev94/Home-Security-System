#include "SensorInfo.h"

SensorInfo::SensorInfo(bool win1, bool win2, bool dr)
{
	window1 = win1;
	window2 = win2;
	door = dr;
}