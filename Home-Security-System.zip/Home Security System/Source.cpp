#include <iostream>  
#include <vector> 
#include <numeric> 
#include <algorithm> 
#include "HomeOwner.h"
#include "KeyHolder.h"

using namespace std;

void main(void)
{
	///Create our HouseSecurity object (i.e. the concrete subject) 
	//Dim mySecureHome As New HouseSecurity()  
	HouseSecurity mySecureHome, *mSC;
	mSC = &mySecureHome;
	///Create few HomeOwners (i.e. ConcreteObservers) 
	//Dim Mum As New Homeowner(mySecureHome,"Mum","123456","Mum@home.ie")  
	//Dim Dad As New Homeowner(mySecureHome,"Dad","2334567","dad@home.ie") 
	//Dim Child As New Homeowner(mySecureHome,"Child","0987654","child@home.ie") 
	HomeOwner Mum(mSC, "Mum", "123456", "Mum@home.ie");
	HomeOwner Dad(mSC, "Dad", "2334567", "dad@home.ie");
	HomeOwner Child(mSC, "Child", "0987654", "child@home.ie");

	///Create few keyholders (i.e. ConcreteObservers) 
	//Dim Neighbour1 As New Keyholder(mySecureHome,"Neighbour1","567890","n1@home.ie") 
	//Dim Neighbour2 As New Keyholder (mySecureHome,"Neighbour2","754321","n2@home.ie") 
	KeyHolder Neighbour1(mSC, "Neighbour1", "567890", "n1@home.ie");
	KeyHolder Neighbour2(mSC, "Neighbour2", "754321", "n2@home.ie");

	///Attach the observers to the house sensor net 
	//mySecureHome.AttachObserver(Mum) 
	//mySecureHome.AttachObserver(Dad) 
	//mySecureHome.AttachObserver(Child) 
	//mySecureHome.AttachObserver(Neighbour1) 
	//mySecureHome.AttachObserver(Neighbour2) 
	//System.Console.WriteLine("After attaching the observers...") 
	IObserver* person;
	person = &Mum;
	mySecureHome.AttachObserver(person);
	person = &Dad;
	mySecureHome.AttachObserver(person);
	person = &Child;
	mySecureHome.AttachObserver(person);
	person = &Neighbour1;
	mySecureHome.AttachObserver(person);
	person = &Neighbour2;
	mySecureHome.AttachObserver(person);
	cout << "After attaching the observers..." << endl;

	///Update the status of the house. 'At this point, all the observers should be notified automatically 
	//mySecureHome.SetSensorStatus(New sensorInfo())
	SensorInfo newinfo;
	mySecureHome.SetSensorStatus(newinfo);

	///Just write a blank line 
	//System.Console.WriteLine() 
	cout << endl;

	///Remove some observers 
	//mySecureHome.DetachObserver(Mum) 
	//mySecureHome.DetachObserver(Dad) 
	//System.Console.WriteLine("After detaching Mum and Dad...") 
	person = &Mum;
	mySecureHome.DetachObserver(person);
	person = &Dad;
	mySecureHome.DetachObserver(person);
	cout << "After detaching Mum and Dad..." << endl;

	///Update the status of the sensors again  
	//mySecureHome.SetSensorStatus(sensorInfo (true, false, false)) 
	SensorInfo updateinfo(true,false,false);
	mySecureHome.SetSensorStatus(updateinfo);

	///At this point, all the observers should be notified automatically The remaining observers should automatically be notified of the status changes. 
	///Press any key to continue� 
	//System.Console.Read()
	cin.get();
}


