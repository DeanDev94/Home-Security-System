#pragma once

class IObserver ///(Observer)
{
	///Observer: The IObserver Class 'This class is an abstract class.Each homeowner / keyholder must update their sensor status information from using this method using the SecurityStatus pointer 
	//Abstract Class IObserver

public:

	//This method is a must override method [4 marks] 
	//Public pure virtual Sub Update() 
	virtual void Update() = 0;

	//End Class 
	///END CLASS DEFINITION IObserver
};
