#include "IObserver.h"
#include "SecurityStatus.h"
#include "HomeOwner.h"

void SecurityStatus::AttachObserver(IObserver* ob)
{
	observers.push_back(ob);
}

void SecurityStatus::DetachObserver(IObserver* obj)
{
	auto match = find(begin(observers), end(observers), obj);
	observers.erase(match);
}

void SecurityStatus::NotifyObserver()
{
	for (unsigned i = 0; i < observers.size(); i++)
	{

		observers[i]->Update();
		/*IObserver* ob = observers.at(i);
		((HomeOwner*)ob)->Update();*/
	};
}