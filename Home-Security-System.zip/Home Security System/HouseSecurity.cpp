#include "HouseSecurity.h"

SensorInfo HouseSecurity::GetSensorStatus()
{
	return mySensorStatus;
};

void HouseSecurity::SetSensorStatus(SensorInfo info)
{
	mySensorStatus = info;
	NotifyObserver();
};