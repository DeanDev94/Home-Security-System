#pragma once

struct SensorInfo
{
	///SensorInfo: This is a data structure to hold the status of the house sensors 
	//Public structure SensorInfo [4 marks] 

	//private window1 As Boolean 
	///You could use an STL vector here as well� 
	bool window1;

	//private window2 As Boolean 
	bool window2;

	//private door As Boolean
	bool door;

	///This is the constructor [5 marks]
	//Public Sub New(Optional ByVal window1  As Boolean = False, _  Optional ByVal window2 As Boolean = False, _ Optional ByVal door As Boolean = False) 
	//Me.window1 = window1   
	//Me.window2 = window2   
	//Me.door = door  
	//End Sub 
public:
	SensorInfo(bool window1 = false, bool window2 = false, bool door = false);
	//End Class 
	///END CLASS DEFINITION SensorInfo
};
