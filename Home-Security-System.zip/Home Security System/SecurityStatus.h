#pragma once
#include "IObserver.h"
#include <vector> 

using namespace std;

class SecurityStatus ///(Subject)
{
	///Subject : The SecurityStatus Class [3 marks] 
	//Public Class SecurityStatus 

	///A private list of observers �(Note: you will need to cast the homeowner/ keyholder to an IObserver pointer) [5 marks] 
	//Private observers As STL vector (of IObserver Pointers) 
	vector <IObserver*> observers;

public:

	///Routine to attach an observer [5 marks] 
	//Public Sub AttachObserver(obj As IObserver pointer) 
	//observers.Add(obj) 
	//End Sub 
	void AttachObserver(IObserver* ob);

	///Routine to remove an observer [5 marks]  
	//Public Sub DetachObserver(obj As IObserver pointer) 
	//observers.Remove(obj) 
	//End Sub 
	void DetachObserver(IObserver* ob);

	///Routine to notify all observers [8 marks]  
	//Public Sub NotifyObservers() 
	//Dim o As IObserver For Each o In observers 
	//o.Update() 
	//Next 
	//End Sub
	void NotifyObserver();

	//End Class 
	///END CLASS DEFINITION SecurityStatus
};
