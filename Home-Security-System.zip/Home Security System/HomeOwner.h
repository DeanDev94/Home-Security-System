#pragma once
#include <iostream>
#include "IObserver.h"
#include "SensorInfo.h"
#include "HouseSecurity.h"

using namespace std;

class HomeOwner :public IObserver///(ConcreteObserver)
{
	///ConcreteObserver: The HomeOwner Class inherits from IObserver, and overrides Update method [5 marks]
	//Public Class HomeOwner Inherits IObserver 

	///This variable holds the current state of the sensors [4 marks] 
	//Private currentSensorState as SensorInfo 
	SensorInfo currentSensorState;

	///These variables hold the personal information of the Homeowner 
	//Private myPhoneNumber As string 
	//Private myEmail As string 
	//Private myName As String 
	string myPhoneNumber;
	string myEmail;
	string myName;

	///This is a pointer to the HouseSecurity in the system 
	//Private house As HouseSecurity pointer 
	HouseSecurity *h;

public:
	///Update() is called from Notify function, in the HouseSecurity class [6 marks] 
	//Public Overrides Sub Update ()  
	//currentSensorState = house.GetSensorStatus() 
	//System.Console.WriteLine("Homeowner {0} says that the status of windows 1, 2 and 3is {1},{2},{3} ", _ myName, currentSensorState.window1, currentSensorState.Window2, currentSensorState.door) 
	//End Sub 
	void Update();

	///A constructor which allows creating a pointer to a HouseSecurity object  [5 marks]
	//Public Sub New(ByVal home As HouseSecurity pointer, ByVal homeOwnerName As String, phone as string, email as string)  
	//house = home myName = homeOwnerName 
	//PhoneNumber = phone 
	//myEmail = email 
	//End Sub 
	HomeOwner(HouseSecurity *h, string name, string phone, string email);
	//End Class 
	///END CLASS DEFINITION HomeOwner
};
